import paramiko
import sys
import logging

logging.basicConfig(level=logging.INFO)

transport = paramiko.Transport(('srv1474370.hstgr.cloud', 22))
try:
    transport.connect(username='root', password='Aom17102544@')
    if transport.is_authenticated():
        print("SUCCESS authenticated!")
    else:
        print("Not authenticated.")
except paramiko.ssh_exception.AuthenticationException:
    print("AUTH ERROR. Allowed auth methods:")
    try:
        print(transport.auth_none('root'))
    except Exception as e:
        print(f"Exception during auth_none: {e}")
except Exception as e:
    print(f"Other error: {e}")
finally:
    transport.close()
