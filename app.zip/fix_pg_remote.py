import paramiko

host = 'srv1474370.hstgr.cloud'
port = 22
username = 'root'
password = 'Aom17102544@'

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, port, username, password)

sftp = ssh.open_sftp()
with sftp.file('/etc/postgresql/16/main/postgresql.conf', 'r') as f:
    text = f.read().decode('utf-8')

text = text.replace("#listen_addresses = 'localhost'", "listen_addresses = '*'")
text = text.replace("listen_addresses = 'localhost'", "listen_addresses = '*'")

with sftp.file('/etc/postgresql/16/main/postgresql.conf', 'w') as f:
    f.write(text.encode('utf-8'))

ssh.exec_command("systemctl restart postgresql")
ssh.close()
print("Done fixing postgresql.conf remotely.")
