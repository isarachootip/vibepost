const { Client } = require('ssh2');
const net = require('net');

const ssh = new Client();
ssh.on('ready', () => {
  const server = net.createServer(socket => {
    ssh.forwardOut('127.0.0.1', 12345, '127.0.0.1', 5432, (err, stream) => {
      if (err) {
        console.error('Forward error:', err);
        return socket.end();
      }
      socket.pipe(stream).pipe(socket);
    });
  }).listen(5433, '127.0.0.1', () => {
    console.log('Tunnel listening on 127.0.0.1:5433');
  });
}).on('error', err => {
  console.error('SSH connection error:', err);
}).connect({
  host: 'srv1474370.hstgr.cloud',
  port: 22,
  username: 'root',
  password: 'Aom17102544@',
  readyTimeout: 20000
});
