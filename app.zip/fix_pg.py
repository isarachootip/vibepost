import os
conf='/etc/postgresql/16/main/postgresql.conf'
with open(conf, 'r') as f:
    text = f.read()
text = text.replace("#listen_addresses = 'localhost'", "listen_addresses = '*'")
text = text.replace("listen_addresses = 'localhost'", "listen_addresses = '*'")
with open(conf, 'w') as f:
    f.write(text)
os.system("systemctl restart postgresql")
