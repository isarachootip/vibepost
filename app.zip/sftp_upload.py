import paramiko
import os

host = "srv1474370.hstgr.cloud"
port = 22
username = "root"
password = "Aom17102544@"

local_file = "app.zip"
remote_file = "/root/content_project_deploy.zip"

print(f"Connecting to {host}...")
try:
    transport = paramiko.Transport((host, port))
    transport.connect(username=username, password=password)
    sftp = paramiko.SFTPClient.from_transport(transport)
    
    print(f"Uploading {local_file} to {remote_file}...")
    sftp.put(local_file, remote_file)
    print("Upload complete!")
    
    sftp.close()
    transport.close()
except Exception as e:
    print(f"Error: {e}")
    exit(1)
