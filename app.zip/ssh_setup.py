import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
    ssh.connect('srv1474370.hstgr.cloud', username='root', password='Aom17102544@', timeout=10)

    commands = [
        "sudo -u postgres psql -c \"ALTER USER admin CREATEDB;\""
    ]

    for cmd in commands:
        print(f"Running: {cmd}")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        print("OUT:", stdout.read().decode())
        print("ERR:", stderr.read().decode())
except Exception as e:
    print(f"Error: {e}")
finally:
    ssh.close()
