import codecs
path = 'src/app/dashboard/multi-post/page.tsx'
with codecs.open(path, 'r', 'utf-8') as f:
    content = f.read()

content = content.replace('\\`', '`').replace('\\${', '${')

with codecs.open(path, 'w', 'utf-8') as f:
    f.write(content)
print("Fixed file.")
