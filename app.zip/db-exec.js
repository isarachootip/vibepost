const { Client } = require('ssh2');
const conn = new Client();
const cmd = process.argv[2];

if (!cmd) {
  console.error("Usage: node db-exec.js '<command>'");
  process.exit(1);
}

conn.on('ready', () => {
  conn.exec(cmd, (err, stream) => {
    if (err) throw err;
    stream.on('close', (code, signal) => {
      conn.end();
    }).on('data', (data) => {
      process.stdout.write(data);
    }).stderr.on('data', (data) => {
      process.stderr.write(data);
    });
  });
}).on('error', (err) => {
  console.error('Connection error:', err);
}).connect({
  host: '187.127.96.51',
  port: 22,
  username: 'root',
  password: 'Aom17102544@',
  readyTimeout: 20000
});
