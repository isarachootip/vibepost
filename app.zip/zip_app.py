import os
import zipfile

def zipdir(path, ziph):
    for root, dirs, files in os.walk(path):
        # Exclude node_modules, .next, .git
        if 'node_modules' in root or '.next' in root or '.git' in root:
            continue
        for file in files:
            if file == 'app.zip':
                continue
            ziph.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), path))

if __name__ == '__main__':
    zipf = zipfile.ZipFile('app.zip', 'w', zipfile.ZIP_DEFLATED)
    zipdir('.', zipf)
    zipf.close()
    print("Zipped successfully to app.zip")
