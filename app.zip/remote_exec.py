import paramiko
import sys
import io

# Force stdout to handle utf-8 safely in Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

host = 'srv1474370.hstgr.cloud'
port = 22
username = 'root'
password = 'Aom17102544@'

commands = [
    "echo 'Building Docker Image... (This may take a few minutes)'",
    "cd /root/content_app && docker build -t content_project:latest .",
    "echo 'Restarting Container...'",
    "docker stop content_app || true",
    "docker rm content_app || true",
    "docker run -d --name content_app --restart always --network host -e DATABASE_URL='postgresql://admin:Aom17102544%40@127.0.0.1:5432/contentdb?schema=public' -e AUTH_SECRET='a-very-secure-random-string-for-nextauth-demo' -e AUTH_TRUST_HOST='true' -e PORT=3000 -e HOSTNAME=0.0.0.0 content_project:latest",
    "echo 'Checking Container Status...'",
    "docker ps | grep content_app"
]

try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host, port, username, password)
    
    for cmd in commands:
        print(f"--- Executing: {cmd} ---")
        stdin, stdout, stderr = ssh.exec_command(cmd)
        
        # Read the output sequentially
        exit_status = stdout.channel.recv_exit_status()
        out = stdout.read().decode('utf-8', errors='replace').strip()
        err = stderr.read().decode('utf-8', errors='replace').strip()
        
        if out: print(out)
        if err: print("WARNING/ERROR:", err)
        
        if exit_status != 0 and "|| true" not in cmd:
            print(f"Command failed with exit code {exit_status}")
            sys.exit(exit_status)
    
    ssh.close()
    print("=== Deployment script completed successfully! ===")
except Exception as e:
    print(f'Exception: {e}')
