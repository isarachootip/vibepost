import paramiko
import sys

if len(sys.argv) < 2:
    print("Usage: python ssh_cmd.py '<command>'")
    sys.exit(1)

cmd = sys.argv[1]

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
try:
    ssh.connect('srv1474370.hstgr.cloud', username='root', password='Aom17102544@', timeout=10)
    stdin, stdout, stderr = ssh.exec_command(cmd)
    
    out = stdout.read().decode('utf-8', errors='replace')
    err = stderr.read().decode('utf-8', errors='replace')
    
    print("STDOUT:\n")
    print(out.encode('ascii', 'replace').decode('ascii'))
    if err:
        print("STDERR:\n")
        print(err.encode('ascii', 'replace').decode('ascii'))
        
except Exception as e:
    print(f"Connection failed: {str(e)}")
finally:
    ssh.close()
